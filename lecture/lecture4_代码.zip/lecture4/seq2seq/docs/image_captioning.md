## Coming Soon

This tutorial is coming soon. It is easy to swap out the RNN encoder with a Convolutional Neural Network to perform image captioning.