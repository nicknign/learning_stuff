解压数据文件，将数据文件存放在和`babi_input.py`中的`babi_train_raw`相符合的地址

运行`python babi_train.py`和`python babi_test.py`，参考代码了解运行代码时的flag
