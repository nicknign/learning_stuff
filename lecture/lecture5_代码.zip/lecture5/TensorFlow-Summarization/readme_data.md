 ## Dataset
Please check [harvardnlp/sent-summary](https://github.com/harvardnlp/sent-summary).

下载之后解压，
* 将train子文件夹的数据拷贝到 TensorFlow-Summarization/data 文件夹里面
* 将DUC2003, DUC2004, Giga中的input.txt拷贝到TensorFlow-Summarization/data 文件夹里面的 test.duc2003.txt, test.duc2004.txt 和 test.giga.txt


